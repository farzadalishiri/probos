برنامه نویسی ربات تلگرامی با امکانات فوق پیشرفته و بدون قطعی 
http://telegram.me/farzad_alishiry

کانال ما
https://t.me/farzadalishiri

کانال ربات های ما 
https://t.me/roboprojects